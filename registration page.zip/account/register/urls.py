from django.urls import path
from django.shortcuts import render
from.import views
from django.contrib.auth import views as auth_user
urlpatterns=[
    
    path('',views.home,name="home"),
    path('register',views.register,name="register"),
    path('login',views.login,name="login"),
    path('sign_up',views.sign_up,name="sign_up"),
    path('log_in',views.log_in,name="log_in"),
    path('login',views.login,name="login"),
    path('logout',views.logout,name="logout")
]