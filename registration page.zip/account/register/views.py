from django.shortcuts import render,redirect
from django.http import HttpResponse 
from django.contrib.auth.models import User
from django.contrib import auth
from django.contrib.auth import authenticate
from django.contrib import messages
from django.contrib.auth.hashers import make_password, check_password

def logout(request):
    auth.logout(request)
    return redirect('/')
def home(request):
    return render(request,"register.html")
def register(request):
    return render(request,'registration.html')
def login(request):
    if request.method=="POST":
        id=request.POST["username"]
        password=request.POST["password"]
        encryptedpassword=make_password(request.POST['password'])
        print(encryptedpassword)
        print(id,password)
        nameuser=auth.authenticate(username=id,password=password)
        if nameuser is not None:
            return render(request,"home.html",{'name':id})
        else:
            messages.info(request,"invalid login")
            return redirect("login")
    else:
        return render(request,"index.html")
        
def log_in(request):
    return render(request,'index.html')
def sign_up(request):

    if request.method=="POST":
        first_name=request.POST["first_name"]
        last_name=request.POST["last_name"]
        user_name=request.POST["user_name"]
        email=request.POST["email"]
        password1=request.POST["password1"]
        password2=request.POST["password2"]
        if password1==password2:
            if User.objects.filter(username=user_name).exists():
                print("username already taken")
                messages.info(request,"username taken")
                return redirect("register")
            elif User.objects.filter(email=email).exists():
                print("email already taken")
                messages.info(request,"email taken")
                return redirect("register")
            else:
                encryptedpassword=make_password(password1)
                nameuser=User(username=user_name,first_name=first_name,last_name=last_name,email=email,password=encryptedpassword)
                User.is_active=True
                nameuser.save()
                print("user created")
                messages.info(request,"user created")
                return redirect("/")
        else:
            print("password mismatch...")
            messages.info(request,"password mismatch")
            return redirect("register")
    return redirect('/')

